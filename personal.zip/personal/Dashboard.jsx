import { useState } from "react";
import { Link } from "react-router-dom";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";
import {
  FaTasks, FaCheckCircle, FaClock, FaExclamationCircle,
  FaPlus, FaBriefcase, FaUser, FaHeart, FaBook, FaMoneyBill
} from "react-icons/fa";
import "../personal/dashboard.css";

const weeklyData = [
  { day: "Mon", Completed: 4, InProgress: 2, Pending: 1 },
  { day: "Tue", Completed: 3, InProgress: 2, Pending: 2 },
  { day: "Wed", Completed: 5, InProgress: 3, Pending: 2 },
  { day: "Thu", Completed: 2, InProgress: 4, Pending: 3 },
  { day: "Fri", Completed: 6, InProgress: 2, Pending: 1 },
  { day: "Sat", Completed: 3, InProgress: 2, Pending: 4 },
  { day: "Sun", Completed: 1, InProgress: 1, Pending: 2 },
];

const pieData = [
  { name: "Completed", value: 5, color: "#4caf50" },
  { name: "In Progress", value: 4, color: "#f59e0b" },
  { name: "Pending", value: 6, color: "#ef4444" },
];

const recentTasks = [
  { title: "Complete project proposal", category: "Work", due: "2026-03-02", status: "Completed" },
  { title: "Review pull requests", category: "Work", due: "2026-03-03", status: "Completed" },
  { title: "Morning jog - 5km", category: "Health", due: "2026-03-04", status: "Completed" },
  { title: "Read 'Atomic Habits' chapter 5", category: "Learning", due: "2026-03-05", status: "In Progress" },
  { title: "Prepare team standup notes", category: "Work", due: "2026-03-04", status: "In Progress" },
  { title: "Pay electricity bill", category: "Finance", due: "2026-03-06", status: "Pending" },
];

const categories = [
  { name: "Work", icon: <FaBriefcase />, done: 3, total: 5 },
  { name: "Personal", icon: <FaUser />, done: 0, total: 2 },
  { name: "Health", icon: <FaHeart />, done: 1, total: 3 },
  { name: "Learning", icon: <FaBook />, done: 0, total: 2 },
  { name: "Finance", icon: <FaMoneyBill />, done: 1, total: 3 },
];

const statusColors = {
  Completed: { bg: "#dcfce7", color: "#16a34a" },
  "In Progress": { bg: "#fef3c7", color: "#d97706" },
  Pending: { bg: "#fee2e2", color: "#dc2626" },
};

const statusDots = {
  Completed: "#4caf50",
  "In Progress": "#f59e0b",
  Pending: "#ef4444",
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="db-tooltip">
        <p className="db-tooltip-label">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }}>
            {p.name}: {p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

function Dashboard() {
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "short", day: "numeric"
  });

  return (
    <div className="db-page">
      {/* HEADER */}
      <header className="db-header">
        <div className="db-header-left">
          <Link to="/landing" className="db-logo">
            <span>📚</span>
            <span className="db-logo-text">PTMs</span>
          </Link>
          <div className="db-header-title">
            <h2 className="db-title">Dashboard</h2>
            <p className="db-subtitle">Personal Task Management System</p>
          </div>
        </div>
        <div className="db-header-right">
          <span className="db-date">📅 {today}</span>
          <Link to ="/tasks" className="db-add-link">
          <button className="db-add-btn">
            <FaPlus /> Add Task
          </button>
          </Link>
        </div>
      </header>

      <div className="db-body">
        {/* STAT CARDS */}
        <div className="db-stats">
          <div className="db-stat-card">
            <div className="db-stat-top">
              <div>
                <p className="db-stat-label">Total Tasks</p>
                <p className="db-stat-number">15 <span className="db-stat-pct">(100%)</span></p>
              </div>
              <div className="db-stat-icon db-icon-total"><FaTasks size={22} /></div>
            </div>
            <div className="db-stat-bar"><div className="db-bar-fill db-bar-total" style={{ width: "100%" }} /></div>
          </div>

          <div className="db-stat-card">
            <div className="db-stat-top">
              <div>
                <p className="db-stat-label">Completed</p>
                <p className="db-stat-number">5 <span className="db-stat-pct">(33%)</span></p>
              </div>
              <div className="db-stat-icon db-icon-done"><FaCheckCircle size={22} /></div>
            </div>
            <div className="db-stat-bar"><div className="db-bar-fill db-bar-done" style={{ width: "33%" }} /></div>
          </div>

          <div className="db-stat-card">
            <div className="db-stat-top">
              <div>
                <p className="db-stat-label">In Progress</p>
                <p className="db-stat-number">4 <span className="db-stat-pct">(27%)</span></p>
              </div>
              <div className="db-stat-icon db-icon-progress"><FaClock size={22} /></div>
            </div>
            <div className="db-stat-bar"><div className="db-bar-fill db-bar-progress" style={{ width: "27%" }} /></div>
          </div>

          <div className="db-stat-card">
            <div className="db-stat-top">
              <div>
                <p className="db-stat-label">Pending</p>
                <p className="db-stat-number">6 <span className="db-stat-pct">(40%)</span></p>
              </div>
              <div className="db-stat-icon db-icon-pending"><FaExclamationCircle size={22} /></div>
            </div>
            <div className="db-stat-bar"><div className="db-bar-fill db-bar-pending" style={{ width: "40%" }} /></div>
          </div>
        </div>

        {/* CHARTS ROW */}
        <div className="db-charts-row">
          <div className="db-card db-chart-bar">
            <h3 className="db-card-title">Weekly Activity</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={weeklyData} barCategoryGap="30%">
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#888", fontSize: 13 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: "#888", fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="Completed" fill="#4caf50" radius={[4, 4, 0, 0]} />
                <Bar dataKey="InProgress" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Pending" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="db-card db-chart-pie">
            <h3 className="db-card-title">Status Overview</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={100}
                  dataKey="value"
                  paddingAngle={3}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Legend
                  iconType="circle"
                  iconSize={10}
                  formatter={(value) => <span style={{ color: "#555", fontSize: 13 }}>{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* RECENT TASKS + CATEGORIES */}
        <div className="db-bottom-row">
          <div className="db-card db-recent">
            <h3 className="db-card-title">Recent Tasks</h3>
            <ul className="db-task-list">
              {recentTasks.map((task, i) => (
                <li key={i} className="db-task-item">
                  <div className="db-task-left">
                    <span className="db-task-dot" style={{ backgroundColor: statusDots[task.status] }} />
                    <div>
                      <p className="db-task-title">{task.title}</p>
                      <p className="db-task-meta">{task.category} · Due {task.due}</p>
                    </div>
                  </div>
                  <span
                    className="db-task-tag"
                    style={{ backgroundColor: statusColors[task.status].bg, color: statusColors[task.status].color }}
                  >
                    {task.status}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="db-card db-categories">
            <h3 className="db-card-title">By Category</h3>
            <ul className="db-cat-list">
              {categories.map((cat, i) => (
                <li key={i} className="db-cat-item">
                  <div className="db-cat-left">
                    <span className="db-cat-icon">{cat.icon}</span>
                    <span className="db-cat-name">{cat.name}</span>
                  </div>
                  <span className="db-cat-count">{cat.done}/{cat.total}</span>
                  <div className="db-cat-bar-bg">
                    <div
                      className="db-cat-bar-fill"
                      style={{ width: cat.total > 0 ? `${(cat.done / cat.total) * 100}%` : "0%" }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
