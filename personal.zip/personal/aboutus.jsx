import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { FaPlusCircle, FaListAlt, FaCheckCircle, FaChartLine } from "react-icons/fa";
import { FaArrowLeft } from "react-icons/fa";
import "../personal/aboutUs.css";

const features = [
  {
    title: "Add Your Tasks",
    description: "Easily create tasks with title, description, due date, and priority.",
    icon: <FaPlusCircle size={50} className="feature-icon" />
  },
  {
    title: "Organize & Categorize",
    description: "Sort your tasks by project, category, or priority to stay on top of everything.",
    icon: <FaListAlt size={50} className="feature-icon" />
  },
  {
    title: "Track Progress",
    description: "Mark tasks as complete and monitor your progress over time with charts.",
    icon: <FaChartLine size={50} className="feature-icon" />
  },
  {
    title: "Achieve Your Goals",
    description: "Stay productive, meet deadlines, and accomplish more every day!",
    icon: <FaCheckCircle size={50} className="feature-icon" />
  },
];

const AboutUs = () => {
  return (
    <div className="aboutus-page">
      <h1 className="h12">About us</h1>

      <div className="aboutus-header">
        <h2>How <span className="h2">PTMS</span> Works</h2>
        <p>
          PTMS is designed to help you organize your personal tasks efficiently 
          and track your productivity with ease. Here's how it works:
        </p>
      </div>

      <div className="features-grid">
        {features.map((feature, idx) => (
          <div key={idx} className="feature-card">
            {feature.icon}
            <h3>{feature.title}</h3>
            <p>{feature.description}</p>
          </div>
        ))}
      </div>

      <div className="text-center">
        <Link to="/" className="back-arrow">
          <FaArrowLeft /> Go Back
        </Link>

        <Link to="/signup">
          <button className="get-started-btn">
            Get Started
            <ArrowRight className="arrow-icon" />
          </button>
        </Link>
      </div>
    </div>
  );
};

export default AboutUs;