import { useState } from "react";
import { Link } from "react-router-dom";
import { FaPlus, FaTrash, FaEdit, FaTimes, FaBriefcase, FaUser, FaHeart, FaBook, FaMoneyBill } from "react-icons/fa";
import "./tasks2.css";

const CATEGORIES = ["Work", "Personal", "Health", "Learning", "Finance"];
const PRIORITIES = ["Low", "Medium", "High"];
const STATUSES = ["Pending", "In Progress", "Completed"];

const categoryColors = {
  Work:     { bg: "#e8f5e9", color: "#2e7d32" },
  Personal: { bg: "#e3f2fd", color: "#1565c0" },
  Health:   { bg: "#fce4ec", color: "#c62828" },
  Learning: { bg: "#f3e5f5", color: "#6a1b9a" },
  Finance:  { bg: "#fff8e1", color: "#f57f17" },
};

const priorityColors = {
  Low:    { bg: "#e8f5e9", color: "#2e7d32" },
  Medium: { bg: "#fff8e1", color: "#f57f17" },
  High:   { bg: "#fee2e2", color: "#dc2626" },
};

const categoryIcons = {
  Work: <FaBriefcase />, Personal: <FaUser />,
  Health: <FaHeart />, Learning: <FaBook />, Finance: <FaMoneyBill />
};

const initialTasks = [
  { id: 1, title: "Complete project proposal", category: "Work",     due: "2026-03-10", priority: "High",   status: "Pending" },
  { id: 2, title: "Morning jog - 5km",         category: "Health",   due: "2026-03-05", priority: "Medium", status: "In Progress" },
  { id: 3, title: "Read Atomic Habits",         category: "Learning", due: "2026-03-08", priority: "Low",    status: "Completed" },
  { id: 4, title: "Pay electricity bill",       category: "Finance",  due: "2026-03-06", priority: "High",   status: "Pending" },
  { id: 5, title: "Call dentist",               category: "Personal", due: "2026-03-07", priority: "Medium", status: "Completed" },
  { id: 6, title: "Review pull requests",       category: "Work",     due: "2026-03-09", priority: "High",   status: "In Progress" },
];

function Tasks() {
  const [tasks, setTasks] = useState(initialTasks);
  const [showModal, setShowModal] = useState(false);
  const [filterCategory, setFilterCategory] = useState("All");
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({
    title: "", category: "Work", due: "", priority: "Medium", status: "Pending"
  });

  const filtered = filterCategory === "All" ? tasks : tasks.filter(t => t.category === filterCategory);
  const getByStatus = (status) => filtered.filter(t => t.status === status);

  const openAdd = () => {
    setEditId(null);
    setForm({ title: "", category: "Work", due: "", priority: "Medium", status: "Pending" });
    setShowModal(true);
  };

  const openEdit = (task) => { setEditId(task.id); setForm({ ...task }); setShowModal(true); };

  const handleSave = () => {
    if (!form.title.trim()) return;
    if (editId) setTasks(tasks.map(t => t.id === editId ? { ...form, id: editId } : t));
    else setTasks([...tasks, { ...form, id: Date.now() }]);
    setShowModal(false);
  };

  const handleDelete = (id) => setTasks(tasks.filter(t => t.id !== id));
  const handleStatusChange = (id, status) => setTasks(tasks.map(t => t.id === id ? { ...t, status } : t));

  return (
    <div className="tk-page">

      {/* HEADER */}
      <header className="tk-header">
        <Link to="/home" className="tk-logo">
          <span>📚</span><span className="tk-logo-text">PTMs</span>
        </Link>
        <nav className="tk-nav">
          <Link to="/landing" className="tk-nav-link">Home</Link>
          <Link to="/tasks" className="tk-nav-link tk-active">My Tasks</Link>
          <Link to="/dashboard" className="tk-nav-link">Dashboard</Link>
          <Link to="/" className="tk-logout">Logout</Link>
        </nav>
      </header>

      <div className="tk-body">

        {/* TOP BAR */}
        <div className="tk-topbar">
          <div>
            <h2 className="tk-title">My Tasks</h2>
            <p className="tk-subtitle">{tasks.length} total tasks</p>
          </div>
          <div className="tk-topbar-right">
            <div className="tk-filters">
              {["All", ...CATEGORIES].map(cat => (
                <button
                  key={cat}
                  className={`tk-filter-btn ${filterCategory === cat ? "tk-filter-active" : ""}`}
                  onClick={() => setFilterCategory(cat)}
                >{cat}</button>
              ))}
            </div>
            <button className="tk-add-btn" onClick={openAdd}><FaPlus /> Add Task</button>
          </div>
        </div>

        {/* KANBAN */}
        <div className="tk-kanban">
          {STATUSES.map(status => (
            <div key={status} className="tk-column">
              <div className={`tk-col-header tk-col-${status.replace(" ", "").toLowerCase()}`}>
                <span className="tk-col-title">{status}</span>
                <span className="tk-col-count">{getByStatus(status).length}</span>
              </div>
              <div className="tk-cards">
                {getByStatus(status).length === 0 && (
                  <div className="tk-empty">No tasks here</div>
                )}
                {getByStatus(status).map(task => (
                  <div key={task.id} className="tk-card-item">
                    <div className={`tk-priority-bar tk-pri-${task.priority.toLowerCase()}`} />
                    <div className="tk-card-top">
                      <span className="tk-cat-badge" style={{ backgroundColor: categoryColors[task.category]?.bg, color: categoryColors[task.category]?.color }}>
                        {categoryIcons[task.category]} {task.category}
                      </span>
                      <span className="tk-pri-badge" style={{ backgroundColor: priorityColors[task.priority]?.bg, color: priorityColors[task.priority]?.color }}>
                        {task.priority}
                      </span>
                    </div>
                    <p className="tk-card-title-text">{task.title}</p>
                    <p className="tk-card-due">📅 Due: {task.due}</p>
                    <select className="tk-status-select" value={task.status} onChange={e => handleStatusChange(task.id, e.target.value)}>
                      {STATUSES.map(s => <option key={s}>{s}</option>)}
                    </select>
                    <div className="tk-card-actions">
                      <button className="tk-btn-edit" onClick={() => openEdit(task)}><FaEdit /> Edit</button>
                      <button className="tk-btn-delete" onClick={() => handleDelete(task.id)}><FaTrash /> Delete</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL */}
      {showModal && (
        <div className="tk-modal-overlay" onClick={() => setShowModal(false)}>
          <div className="tk-modal" onClick={e => e.stopPropagation()}>
            <div className="tk-modal-header">
              <h3>{editId ? "Edit Task" : "Add New Task"}</h3>
              <button className="tk-modal-close" onClick={() => setShowModal(false)}><FaTimes /></button>
            </div>
            <div className="tk-modal-body">
              <label className="tk-modal-label">Title</label>
              <input className="tk-modal-input" placeholder="Task title..." value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
              <label className="tk-modal-label">Category</label>
              <select className="tk-modal-input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
              <label className="tk-modal-label">Due Date</label>
              <input type="date" className="tk-modal-input" value={form.due} onChange={e => setForm({ ...form, due: e.target.value })} />
              <label className="tk-modal-label">Priority</label>
              <select className="tk-modal-input" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                {PRIORITIES.map(p => <option key={p}>{p}</option>)}
              </select>
              <label className="tk-modal-label">Status</label>
              <select className="tk-modal-input" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="tk-modal-footer">
              <button className="tk-modal-cancel" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="tk-modal-save" onClick={handleSave}>{editId ? "Save Changes" : "Add Task"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Tasks;
