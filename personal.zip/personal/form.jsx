import '../personal/signup.css';
import { Link } from "react-router-dom";

function SignUpForm() {
  return (
    <div className="signup-page">
      <div className="signup-card">
        <h1 className="signup-logo">📚 <span className="signup-logotext">PTMs</span></h1>
        <h2 className="signup-title">Create your account</h2>

        <form className="signup-form">
          <label className="signup-label">Name</label>
          <input type="text" className="signup-input" placeholder="Your full name" />

          <label className="signup-label">Email</label>
          <input type="email" className="signup-input" placeholder="your@email.com" />

          <label className="signup-label">Password</label>
          <input type="password" className="signup-input" placeholder="••••••••" />

          <button type="submit" className="signup-btn">Sign Up</button>

          <p className="signup-footer">
            Already have an account?{" "}
            <Link to="/login" className="signup-link">Login</Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default SignUpForm;