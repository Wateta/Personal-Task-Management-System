import '../personal/signup.css';
import { Link } from "react-router-dom";

function LoginForm() {
  return (
    <div className="signup-page">
      <div className="signup-card">
        <h1 className="signup-logo">📚 <span className="signup-logotext">PTMs</span></h1>
        <h2 className="signup-title">Welcome Back 👋</h2>
        <p style={{color:'#888', marginBottom:'20px', fontSize:'0.95rem'}}>login to your account</p>

        <form className="signup-form">
          <label className="signup-label">Email</label>
          <input type="email" className="signup-input" placeholder="your@email.com" />

          <label className="signup-label">Password</label>
          <input type="password" className="signup-input" placeholder="••••••••" />

          <button type="submit" className="signup-btn">Login</button>

          <p className="signup-footer">
            Don't have an account?{" "}
            <Link to="/signup" className="signup-link">create account</Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default LoginForm;